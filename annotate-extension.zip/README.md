# Chrome extension to draw and annotate on Leetcode

Works with most pages with a single vertical scroll and Leetcode

## Current features ##
1. Draw and 

![Screenshot]()

### [Download it](https://chrome.google.com/webstore/detail/github-boxcutter/knapnimomamjogbajmmoefhopnebjbff)
